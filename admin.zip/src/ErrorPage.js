import React from 'react';




function ErrorPage(){
    return(
        <>
        <h4>404 Error! page not found</h4>
        <p>go back</p>
        </>
    )
}

export default ErrorPage;